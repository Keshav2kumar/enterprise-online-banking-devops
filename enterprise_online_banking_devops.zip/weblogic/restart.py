# WLST restart placeholder
print('Restart WebLogic server - implement per environment')
